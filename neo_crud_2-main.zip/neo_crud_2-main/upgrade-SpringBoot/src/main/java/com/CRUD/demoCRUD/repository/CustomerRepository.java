package com.CRUD.demoCRUD.repository;

import com.CRUD.demoCRUD.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, UUID> {
    Customer getCustomerById(UUID id);

    @Query(value = "SELECT p FROM tb_customer p WHERE p.name LIKE %:name%", nativeQuery=true)
    List<Customer> search(@Param("name") String name);


}
