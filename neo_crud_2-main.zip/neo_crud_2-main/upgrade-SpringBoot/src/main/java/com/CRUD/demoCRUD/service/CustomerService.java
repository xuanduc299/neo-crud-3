package com.CRUD.demoCRUD.service;

import com.CRUD.demoCRUD.dto.CustomerDTO;

public interface CustomerService extends  BaseService<CustomerDTO>{
}
