package com.CRUD.demoCRUD.service;

import com.CRUD.demoCRUD.dto.ProductDTO;


public interface ProductService extends BaseService<ProductDTO>{
}
