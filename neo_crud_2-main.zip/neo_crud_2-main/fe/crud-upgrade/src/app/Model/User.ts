export class User {
    // id?: any;
    // name?: string;
    // email?: string;
    // password?: string;
    id?: any;
    makh?: any;
    name?: string;
    quantity?: string;
    sectors?: string;


}