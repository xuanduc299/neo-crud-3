export class Product {
    // id?: any;
    // name?: string;
    // email?: string;
    // password?: string;
    id?: any;
    maSp?: string;
    name?: string;
    date?: string;
    product_width?: string;
    product_height?: string;
    color?: string;
    quantity?: string;
    brand?: string;
    material?: string;
    sectors?: string;


}