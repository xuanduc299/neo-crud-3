import { StudentFilterPipePipe } from './student-filter-pipe.pipe';

describe('StudentFilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new StudentFilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
